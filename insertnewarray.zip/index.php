<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
	</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<a class="navbar-brand" href="https://www.belajar-it.web.id">Belajar IT</a>
</a>		</div>
	</nav>

	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">Insert Anggota Array Baru Dengan PHP</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<?php
			session_start();;
			if(!ISSET($_SESSION['member'])){
				$array['member'][]= array(
						"namadepan" => 'Irvan', 
						"namabelakang" => 'BelajarIT' 
					);
				$_SESSION['member'] = $array;
				
			}
		?>
 
		<div class="col-md-12">
			<form method="POST" action="insert.php">
				<div class="form-group">
					<label>Nama Depan</label>
					<input type="text" name="namadepan" class="form-control" required="required"/>
				</div>
				<div class="form-group">
					<label>Nama Belakang</label>
					<input type="text" name="namabelakang" class="form-control" required="required"/>
				</div>
				<center><button class="btn btn-primary" name="insert">Insert</button></center>
			</form>
			<br>
		</div>
		
		<div class="col-md-8 col-md-offset-2">
			<table class="table table-bordered">
				<thead class="alert-info">
					<tr>
						<th>Nama Depan</th>
						<th>Nama Belakang</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$member = $_SESSION['member'];
						foreach($member['member'] as $key=>$list){
					?>
						<tr><td><?php echo $list['namadepan']?></td><td><?php echo $list['namabelakang']?></td></tr>
					<?php
						}
					?>
					
				</tbody>
			</table>
		</div>
	</div>
</boy>	
</html>