<?php
	session_start();
	
	if(ISSET($_POST['insert'])){
		$firstname=$_POST['namadepan'];
		$lastname=$_POST['namabelakang'];
		
		$array= array(
			"namadepan" => $firstname, 
			"namabelakang" => $lastname 
		);
		

		
		$member = $_SESSION['member'];
		
		$member['member'][]=$array;
		
		
		$_SESSION['member'] = $member;
		
		header("location: index.php");
	}
?>	